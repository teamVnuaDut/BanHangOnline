$(document).ready(function() {

	/* ===== Affix Sidebar ===== */
	/* Ref: http://getbootstrap.com/javascript/#affix-examples */


	$('#doc-menu').affix({
        offset: {
            top: ($('#header').outerHeight(true) + $('#doc-header').outerHeight(true)) + 45,
            bottom: ($('#footer').outerHeight(true) + $('#promo-block').outerHeight(true)) + 75
        }
    });

    /* Hack related to: https://github.com/twbs/bootstrap/issues/10236 */
    $(window).on('load resize', function() {
        $(window).trigger('scroll');
    });

    /* Activate scrollspy menu */
    $('body').scrollspy({target: '#doc-nav', offset: 100});

    $('#doc-nav li').on('activate.bs.scrollspy', function() {
        // if ( $(this).hasClass('active') && $(this).find('.doc-sub-menu').length > 0 ) {
        //     $(this).find('> a').click();
        //     console.log($(this));
        // }

        if ( $(this).parent().hasClass('doc-sub-menu') ) {
            // console.log(123);
            $('.doc-sub-menu').hide();
            $(this).parent().show();
        }
    });

    $(window).trigger('scroll');

    /* Smooth scrolling */
	$('a.scrollto').on('click', function(e){
        //store hash
        var target = this.hash;
        e.preventDefault();
		$('body').scrollTo(target, 800, {offset: 0, 'axis':'y'});
        console.log(target);

	});


    /* ======= jQuery Responsive equal heights plugin ======= */
    /* Ref: https://github.com/liabru/jquery-match-height */

     $('#cards-wrapper .item-inner').matchHeight();
     $('#showcase .card').matchHeight();

    /* Bootstrap lightbox */
    /* Ref: http://ashleydw.github.io/lightbox/ */

    $(document).delegate('*[data-toggle="lightbox"]', 'click', function(e) {
        e.preventDefault();
        $(this).ekkoLightbox();
    });

    $('#doc-menu > li > a').click(function(e) {
        e.stopPropagation();
        var submenu = $(this).siblings('.doc-sub-menu');

        if (submenu.length) submenu.addClass('active-sub-menu');

        $('.doc-sub-menu').removeClass('active-sub-menu');
        $('.doc-sub-menu:not(.active-sub-menu)').slideUp('fast');

        if (submenu.length) submenu.slideDown('fast');
    });

    $('.doc-sub-menu').hide();
    $('.doc-sub-menu').first().show();



});