=== Creazione FSE ===
Contributors: gracethemes
Tags:blog, news, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.6
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Creazione FSE is a free Luxury WordPress theme for architecture, building, construction, interior design, decorator, furniture, interior art and dcor, interior planners, renovators, heritage centers, and more. Creazione FSE theme has an extremely appealing homepage. This Free Luxury WordPress Theme looks equally professional and stunning. The homepage has different types of headers and footers that enhance the appearance of your website.This WordPress theme is very appealing and functions well with the latest WordPress version. This Free Luxury WordPress Theme, being a full-site editing theme is easy to customize without hiring any professionals. You do not need any coding knowledge to use this theme. This is an SEO-optimized theme. It means you do not need to worry about the ranking of your website on the SERPs. When you make use of this WordPress theme, your website automatically ranks higher in the SERPs. Also, this theme is compatible with a lot of SEO plugins such as Yoast SEO and Rank Math. This theme is flexible and dynamic. Anyone can operate this theme with ease. It is compatible with multiple devices like PCs, laptops, smartphones, and tablets. This theme has qualified for the mobile-friendly test conducted by Google. All these features make this theme the right choice for you.

== Theme License & Copyright == 

* Creazione FSE WordPress Theme, Copyright 2024 Grace Themes 
* Creazione FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

== Resources ==

Theme is Built using the following resource bundles.

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/111935 ( Header Banner image)



= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1068960 (sections 4 column 1 image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/509549  (sections 4 column 2 image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1372784  (sections 4 column 3 image)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1581469  (Welcome to image 1)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1393880  (Welcome to image 2)


= Icon Images =

  * Grace Themes Self Designed icons images:	
	assets/images/crz-head-icon-email.png
	assets/images/crz-head-icon-map.png
	assets/images/crz-head-icon-phone.png
	assets/images/crz-services-icon01.png
	assets/images/crz-services-icon02.png
	assets/images/crz-services-icon03.png
	assets/images/list-icon-arrow.png
	assets/images/orange-icon.png	

    
For any help you can mail us at support@gracethemes.com